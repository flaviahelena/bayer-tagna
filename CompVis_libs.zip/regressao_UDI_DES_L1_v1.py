# Used for both codes
import cv2 as cv
import sys
import numpy as np

#Used for model refinement code
import pandas as pd
from statsmodels.formula.api import ols

#Used for color analysis only
from sklearn.cluster import KMeans
from datetime import datetime
from collections import Counter, defaultdict
#from yellowbrick.cluster import KElbowVisualizer

#Image management
import urllib.request
import glob
import time

#Supress warnings
import warnings

def fxn():
    warnings.warn("deprecated", DeprecationWarning)

with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    fxn()
warnings.filterwarnings("ignore")

## Color Analysis code


def milho(foto,low, high): 
  hsv = cv.cvtColor(foto, cv.COLOR_BGR2HSV)
  mask = cv.inRange(hsv,low, high)
  imask = mask>0
  amarelo = np.zeros_like(foto, np.uint8)
  amarelo[imask] = foto[imask]
  return amarelo

def visualize_colors(cluster, centroids):
    # Get the number of different clusters, create histogram, and normalize
    labels = np.arange(0, len(np.unique(cluster.labels_)) + 1)
    (hist, _) = np.histogram(cluster.labels_, bins = labels)
    hist = hist.astype("float")
    hist /= hist.sum()

    # Create frequency rect and iterate through each cluster's color and percentage
    rect = np.zeros((50, 300, 3), dtype=np.uint8)
    colors = sorted([(percent, color) for (percent, color) in zip(hist, centroids)])
    start = 0
    cores = []
    for (percent, color) in colors:
        percentual = float("{:0.2f}".format(percent * 100))
        #print(color, "{:0.2f}%".format(percent * 100))
        cores.append(percentual)
        end = start + (percent * 300)
        cv.rectangle(rect, (int(start), 0), (int(end), 50), \
                      color.astype("uint8").tolist(), -1)
        start = end
    #print(cores)
    return rect

#def fc_perda_branca_nc(img):
def fc_perda_branca_nc(img):
    #filename = input('File name: ')
    #url = r'C:\\Users\\TAGNA\\Desktop\\Bayer\\sprint 2\\mascaras separacao de cores\\originais e mascaras\\Finais\\'  
    #url = r'C:\\Users\\TAGNA\\Desktop\\Camera Bayer\\Codigos_modelo\\'
    #url = url + str(filename)
    #url = url + '.jpg'
    #img = cv.imread(str(url))
    img2 = img[50:730, 390:980]

    full = milho(img2,(0, 0, 143), (180, 255, 255))
    #amarelo = milho(img,(0, 118, 190), (33, 255,255))
    cv.imwrite(r'maskFULL.jpg', full)
    image = cv.cvtColor(full, cv.COLOR_BGR2RGB)
    reshape = image.reshape((image.shape[0] * image.shape[1], 3))
    start_time = datetime.now()
    centroid_start = np.array([[0,0,0], #PRETO
                               [248,167,48], #BEGE
                               [160, 62, 0], #BEGE2
                               [153, 82, 33], #iNTERMEDIARIO DO MEIO
                               [198, 130, 109], #VERMELHO AMARRONZADO
                               [188, 126, 119], #VERMELHO PERDA
                               [220,138, 22], #AMARELO
                               [238,218,174]], np.float64) #BRANCO
    cluster = KMeans(n_clusters = 8, init = centroid_start).fit(reshape)
    #
    #visualize = visualize_colors(cluster, cluster.cluster_centers_)
    #visualize = cv.cvtColor(visualize, cv.COLOR_RGB2BGR)
    #cv.imshow("teste", visualize)
    #
    end_time = datetime.now()

    
    #print('Duration: {}'.format(end_time - start_time))
    pixels = Counter(cluster.labels_)
    prop = pixels[0]/(sum(pixels.values()))
        
    if (prop >= 0.99)or(prop<=0):
      #print("Esteira vazia")
      return 0
    else:
      pc_perda = (pixels[5]+pixels[7])/(sum(pixels.values())-pixels[0])
      #print('% de perda branca:' + str(round(pc_branco * 100, 2)) + '%')
      pc_perda = pc_perda*100 #value in percentage
      return pc_perda

def url_to_image(url):
	resp = urllib.request.urlopen(url)
	image = np.asarray(bytearray(resp.read()), dtype="uint8")
	image = cv.imdecode(image, cv.IMREAD_COLOR)
	#cv.imwrite('temp.jpg' ,image)
	return(image)

def save_opc(loss,median):
    try:
        Loss = client.get_node("ns=2;i=2")
        Median = client.get_node("ns=2;i=3")
        Loss.set_value(loss)
        Median.set_value(median)
        print('Values saved on OPC Server')
    except:
        print('Error on saving on OPC Server')
  
def correction_factor(loss_value):
    try:
        reg_params = np.load('reg_params.npy')
        return(reg_params[0]+loss_value*reg_params[1])
    except:
        try:
            time.sleep(0.5)
            reg_params = np.load('reg_params.npy')
            return(reg_params[0]+loss_value*reg_params[1])
        except:
            print('Error on loading correction factor file')
            print('No correction factor applied')
            return(loss_value)


## Neural Networks correction

# Get the names of the output layers
def getOutputsNames(net):
    # Get the names of all the layers in the network
    layersNames = net.getLayerNames()
    # Get the names of the output layers, i.e. the layers with unconnected outputs
    return [layersNames[i[0] - 1] for i in net.getUnconnectedOutLayers()]

# Remove the bounding boxes with low confidence using non-maxima suppression
def postprocess(frame, outs):
    frameHeight = frame.shape[0]
    frameWidth = frame.shape[1]

    classIds = []
    confidences = []
    boxes = []
    # Scan through all the bounding boxes output from the network and keep only the
    # ones with high confidence scores. Assign the box's class label as the class with the highest score.
    classIds = []
    confidences = []
    boxes = []
    for out in outs:
        #print("out.shape : ", out.shape)
        for detection in out:
            #if detection[4]>0.001:
            scores = detection[5:]
            classId = np.argmax(scores)
            #if scores[classId]>confThreshold:
            confidence = scores[classId]
            #if detection[4]>confThreshold:
                #print(detection[4], " - ", scores[classId], " - th : ", confThreshold)
                #print(detection)
            if confidence > confThreshold:
                center_x = int(detection[0] * frameWidth)
                center_y = int(detection[1] * frameHeight)
                width = int(detection[2] * frameWidth)
                height = int(detection[3] * frameHeight)
                left = int(center_x - width / 2)
                top = int(center_y - height / 2)
                classIds.append(classId)
                confidences.append(float(confidence))
                boxes.append([left, top, width, height])

    # Perform non maximum suppression to eliminate redundant overlapping boxes with
    # lower confidences.
    indices = cv.dnn.NMSBoxes(boxes, confidences, confThreshold, nmsThreshold)
    for i in indices:
        i = i[0]
        box = boxes[i]
        left = box[0]
        top = box[1]
        width = box[2]
        height = box[3]
        #drawPred(classIds[i],confidences[i], left, top, left + width, top + height)

    font = cv.FONT_HERSHEY_PLAIN
    for i in range(len(boxes)):
        if i in indices:
            x, y, w, h = boxes[i]
            label = str(classes[classIds[i]])
            #color = colors[i]
            color = (0,0,0) #paint black
            cv.rectangle(frame, (x, y), (x + w, y + h), color, -1)
            
            
def paintBlack(image,train_files_path = ''):
    #Declare global variables
    global confThreshold
    global nmsThreshold
    global inpWidth
    global inpHeight
    global classesFile
    global classes
    global modelConfiguration
    global modelWeights
    global net

    ## image = cv.imread(url)
    # Initialize the parameters
    confThreshold = 0.5  #Confidence threshold
    nmsThreshold = 0.4  #Non-maximum suppression threshold

    inpWidth = 608     #Width of network's input image
    inpHeight = 608     #Height of network's input image

    # Load names of classes
    classesFile = "obj.names";

    classes = None
    with open(classesFile, 'rt') as f:
        classes = f.read().rstrip('\n').split('\n')

    # Give the configuration and weight files for the model and load the network using them.    
    modelConfiguration = "yolo-obj.cfg";
    modelWeights = "yolo-obj_final.weights";

    net = cv.dnn.readNetFromDarknet(modelConfiguration, modelWeights)
    net.setPreferableBackend(cv.dnn.DNN_BACKEND_OPENCV)
    net.setPreferableTarget(cv.dnn.DNN_TARGET_CPU)


    # Create a 4D blob from a frame.
    blob = cv.dnn.blobFromImage(image, 1/255, (inpWidth, inpHeight), [0,0,0], 1, crop=False)

    # Sets the input to the network
    net.setInput(blob)

    # Runs the forward pass to get output of the output layers
    outs = net.forward(getOutputsNames(net))

    # Remove the bounding boxes with low confidence
    postprocess(image, outs)

    # Put efficiency information. The function getPerfProfile returns the overall time for inference(t) and the timings for each of the layers(in layersTimes)
    t, _ = net.getPerfProfile()
    label = 'Inference time: %.2f ms' % (t * 1000.0 / cv.getTickFrequency())
    #cv.putText(frame, label, (0, 15), cv.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255))

    # Write the frame with the detection boxes
    return(image.astype(np.uint8))

def regAdjust(unAdjImgLoss, AdjImgLoss):
    
    print('----------------------------')
    print('Adjusting regression model')

    x = unAdjImgLoss
    y = AdjImgLoss


    #Create dataframe
    data = {'Y': y,
            'X': x}
    df = pd.DataFrame (data, columns = ['Y','X'])

    #Adjust model
    model = ols("Y ~ X", data=df)
    results = model.fit()
    print('\n',results.summary())

    #Perform hypothesis test
    print('\n')
    significance = 0.05

    reg_params = results.params
    model_p = results.f_pvalue
    param_p = results.pvalues
    if(model_p <= significance):
      for i in range(np.shape(param_p)[0]):
        if(param_p[i]>= significance):
          print('Warning: Non-significative parameter \u03B2',i)
      print('Model Accepted')
      try:
          np.save('reg_params.npy',reg_params)
          print('Model parameters updated')
      except:
          try:
              time.sleep(10)
              np.save('reg_params.npy',reg_params)
              print('Model parameters updated')
          except:
              print('Error on saving regression parameters')
    else:
      print('Model Rejected')

    print('\nModel interpretation:',
          '\nFixed discount of ',round(results.params[0],2),'%',
          '\nPercentage discount of ',round(100*(1-results.params[1]),2),'%')

    unAdjImgLoss = [] #Regression X
    AdjImgLoss = [] #Regression Y
    
def main():

    global unAdjImgLoss
    global AdjImgLoss
    
    #For testing purposes with existing images
    path = r"D:\Ultima Versão RN\fotos"
    image_vector = []
    median_vector = []
    median_points = 150

    image = url_to_image(url)
    #scale_percent = 250
    #width = int(picture.shape[1] * scale_percent / 100)
    #height = int(picture.shape[0] * scale_percent / 100)
    #dsize = (width, height)
    #image = cv.resize(picture,dsize)
    
    estimated_loss = fc_perda_branca_nc(image)
    if(estimated_loss != 0):
        median_vector.append(estimated_loss)
        output = paintBlack(image)
        finalLoss = fc_perda_branca_nc(output)
        print("Loss: ", round(estimated_loss, 2), "%")
        print("Adj Loss: ", round(finalLoss, 2), "%")
        print((49-np.shape(AdjImgLoss)[0]) ,"more images are needed to perform regression.")
        cv.imwrite('test_regression.jpg',image)
        cv.imwrite('test_regression_black.jpg',output)
        unAdjImgLoss.append(estimated_loss)
        AdjImgLoss.append(finalLoss)
        
        
    if(np.shape(unAdjImgLoss)[0] == 50):
       regAdjust(unAdjImgLoss, AdjImgLoss)
       unAdjImgLoss = [] #Regression X
       AdjImgLoss = [] #Regression Y
    
url =  r'http://10.246.234.63/jpeg?id=1'

#vector for regression
unAdjImgLoss = [] #Regression X
AdjImgLoss = [] #Regression Y
    
while True:
    main()
