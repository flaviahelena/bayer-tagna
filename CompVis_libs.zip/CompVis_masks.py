#Libraries
import numpy as np
import sys
import cv2 as cv
import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics import *
from datetime import datetime
from collections import Counter, defaultdict
import CompVis_libs as cvlibs
#import knn_predict as knnp
from joblib import load

#Image management
import urllib.request
import glob
import time


def fc_perda_branca_nc(img ,code, method):

    if (code == 'UDI_DES_L1'):
        img2 = img[50:730, 390:980] ##DONE
        full = cvlibs.milho(img2,(0, 0, 163), (180, 255, 255))
        centroid_start = np.array([[0,0,0], #PRETO
                               [248,167,48], #BEGE
                               [160, 62, 0], #BEGE2
                               [153, 82, 33], #iNTERMEDIARIO DO MEIO
                               [198, 130, 109], #VERMELHO AMARRONZADO
                               [188, 126, 119], #VERMELHO PERDA
                               [220,138, 22], #AMARELO
                               [238,218,174]], np.float64) #BRANCO
        
    
    if (code == 'PTU_DES_L1'):
        img2 = img[0:620, 335:962] ##DONE
        full = cvlibs.milho_bgr(img2,(0, 0, 175), (250, 255, 255))
        centroid_start = np.array([[0,0,0], #PRETO
                               [248,167,48], #BEGE
                               [160, 62, 0], #BEGE2
                               [153, 82, 33], #iNTERMEDIARIO DO MEIO
                               [198, 130, 109], #VERMELHO AMARRONZADO
                               [188, 126, 119], #VERMELHO PERDA
                               [220,138, 22], #AMARELO
                               [238,218,174]], np.float64) #BRANCO
        
    if (code == 'PTU_DES_L2'):
        img2 = img[85:720, 150:1150] ##DONE
        full = cvlibs.milho_bgr(img2,(0, 0, 186), (244, 255, 255))
        centroid_start = np.array([[0,0,0], #PRETO
                               [248,167,48], #BEGE
                               [160, 62, 0], #BEGE2
                               [153, 82, 33], #iNTERMEDIARIO DO MEIO
                               [198, 130, 109], #VERMELHO AMARRONZADO
                               [188, 126, 119], #VERMELHO PERDA
                               [220,138, 22], #AMARELO
                               [238,218,174]], np.float64) #BRANCO
        
    if (code == 'PTU_DES_L3'):
        img2 = img[0:635, 150:1150] ##DONE
        full = cvlibs.milho_bgr(img2,(0, 0, 180), (255, 255, 255))
        centroid_start = np.array([[0,0,0], #PRETO
                               [248,167,48], #BEGE
                               [160, 62, 0], #BEGE2
                               [153, 82, 33], #iNTERMEDIARIO DO MEIO
                               [198, 130, 109], #VERMELHO AMARRONZADO
                               [188, 126, 119], #VERMELHO PERDA
                               [220,138, 22], #AMARELO
                               [238,218,174]], np.float64) #BRANCO
        
    if (code == 'PTU_DES_L4'):
        img2 = img[0:720, 215:795] ##DONE
        dst = cv.fastNlMeansDenoisingColored(img2,None,10,10,7,21)
        full = cvlibs.milho_bgr(dst,(0, 140, 157), (255, 255, 255))
        centroid_start = np.array([[0,0,0], #PRETO
                               [248,167,48], #BEGE
                               [160, 62, 0], #BEGE2
                               [153, 82, 33], #iNTERMEDIARIO DO MEIO
                               [198, 130, 109], #VERMELHO AMARRONZADO
                               [188, 126, 119], #VERMELHO PERDA
                               [220,138, 22], #AMARELO
                               [238,218,174]], np.float64) #BRANCO

    #amarelo = cvlibs.milho(img,(0, 118, 190), (33, 255,255))
    cv.imwrite(r'maskFULL.jpg', full)
    image = cv.cvtColor(full, cv.COLOR_BGR2RGB)
    reshape = image.reshape((image.shape[0] * image.shape[1], 3))
    #start_time = datetime.now()
    
    cluster = KMeans(n_clusters = 8, init = centroid_start).fit(reshape)
    #
    #visualize = cvlibs.visualize_colors(cluster, cluster.cluster_centers_)
    #visualize = cv.cvtColor(visualize, cv.COLOR_RGB2BGR)
    #cv.imshow("teste", visualize)
    #
    #end_time = datetime.now()

    #print('Duration: {}'.format(end_time - start_time))
    pixels = Counter(cluster.labels_)
    prop = pixels[0]/(sum(pixels.values()))
    fillment =  (sum(pixels.values())-pixels[0])/(sum(pixels.values())) #para calculo da vazao

    if (method == 'runtime'):        
        if (prop >= 0.99)or(prop<=0):
          #print("Esteira vazia")
          return [0,0]
        else:
          pc_perda = (pixels[5]+pixels[7])/(sum(pixels.values())-pixels[0])
          #print('% de perda branca:' + str(round(pc_branco * 100, 2)) + '%')
          pc_perda = pc_perda*100 #value in percentage
          output = [pc_perda,fillment]
          #return correction_factor(pc_perda)
          return(output)
        
    if (method == 'regression'):
        if (prop >= 0.99)or(prop<=0):
          #print("Esteira vazia")
          return 0
        else:
          pc_perda = (pixels[5]+pixels[7])/(sum(pixels.values())-pixels[0])
          #print('% de perda branca:' + str(round(pc_branco * 100, 2)) + '%')
          pc_perda = pc_perda*100 #value in percentage
          return pc_perda

def fc_perda_debulha(img, code, nome):
    init_t = time.time()
    if (code == 'PTU_DEB_L1'):
        img2 = img[341:1349, 628:1462]
        full = cvlibs.milho(img2,(0, 0, 180), (255, 255, 255))
        centroid_start = np.array([[0,0,0], #PRETO
                               [38,64,87], #AZUL CALHA
                               [248,167,48], #BEGE
                               [160, 62, 0], #BEGE2
                               [153, 82, 33], #iNTERMEDIARIO DO MEIO
                               [198, 130, 109], #VERMELHO AMARRONZADO
                               [188, 126, 119], #VERMELHO PERDA
                               [220,138, 22], #AMARELO
                               [238,218,174]], np.float64) #BRANCO
        
    if (code == 'PTU_DEB_L2'):
        #reshape = img.reshape((img.shape[0] * img.shape[1], 3))
        #print(reshape)
        img2 = img[0:580, 498:920]
        
        model = load('knn.joblib')
        hist = knnp.extract_color_histogram(img2)
        hist2 = hist.reshape(1, -1)
        img_class = model.predict(hist2)
        print('class',img_class)
        flow_flag = int(img_class)
        print('ff',flow_flag)
        
        full = cvlibs.milho(img2,(0, 135, 0), (180, 255, 255)) 
        centroid_start = np.array([[0,0,0], #PRETO
                                   [98,68,43], #azul calha 2
                                   [45,42,23], #VERDE CALHA
                                   [0, 62, 160],#marrom mais escuro
                                   [102,195,212], #Amarelo mais claro
                                   [30,93,120], #Marrom
                                   [55, 136, 157], #Amarelo mostarda
                                   #teste
                                   [40,118,147], #marrom
                                
                                   
                                   [82,164, 181]], np.uint8) #Amarelo areia  

    image = full
    cv.imwrite(nome + '_' + 'maskFULL_deb_v3.jpg', image)
    reshape = image.reshape((image.shape[0] * image.shape[1], 3))
    #init_t = time.time()
    cluster = pairwise_distances(reshape, centroid_start, metric = 'euclidean')
    pixels = np.zeros(np.shape(cluster)[1])
    for i in range(np.shape(cluster)[0]):
        pixels[np.argmin(cluster[i])]+=1
    
    if(flow_flag==1):
        prop = (sum(pixels)-sum(pixels[2:]))/(sum(pixels))
    else:
        prop = (sum(pixels)-sum(pixels[3:]))/(sum(pixels))
    #print('time:',time.time()-init_t)
    print('time:',time.time()-init_t)
    if (prop >= 0.9999):
      #print("Esteira vazia")
      return [0, flow_flag]
    else:
      pc_perda = 1.0 - prop
      #print('% de perda branca:' + str(round(pc_branco * 100, 2)) + '%')
      pc_perda = pc_perda*100 #value in percentage
      #return correction_factor(pc_perda)
      return [pc_perda, flow_flag]

