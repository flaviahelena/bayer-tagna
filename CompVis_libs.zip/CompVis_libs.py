### RUNTIME ###
###############

import numpy as np
import sys
import cv2 as cv
import numpy as np
from sklearn.cluster import KMeans
from datetime import datetime
from collections import Counter, defaultdict
#from yellowbrick.cluster import KElbowVisualizer

#Image management
import urllib.request
import glob

#OPC functions
#OPCUA
from opcua import Client
import time
#OPCDA
#import OpenOPC
#import pywintypes

#Supress warnings
import warnings

def fxn():
    warnings.warn("deprecated", DeprecationWarning)

with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    fxn()
warnings.filterwarnings("ignore")

def milho(foto,low, high): 
  hsv = cv.cvtColor(foto, cv.COLOR_BGR2HSV)
  mask = cv.inRange(hsv,low, high)
  imask = mask>0
  amarelo = np.zeros_like(foto, np.uint8)
  amarelo[imask] = foto[imask]
  return amarelo

def milho_bgr(foto,low, high): 
  mask = cv.inRange(foto,low, high)
  imask = mask>0
  amarelo = np.zeros_like(foto, np.uint8)
  amarelo[imask] = foto[imask]
  return amarelo

def visualize_colors(cluster, centroids):
    # Get the number of different clusters, create histogram, and normalize
    labels = np.arange(0, len(np.unique(cluster.labels_)) + 1)
    (hist, _) = np.histogram(cluster.labels_, bins = labels)
    hist = hist.astype("float")
    hist /= hist.sum()

    # Create frequency rect and iterate through each cluster's color and percentage
    rect = np.zeros((50, 300, 3), dtype=np.uint8)
    colors = sorted([(percent, color) for (percent, color) in zip(hist, centroids)])
    start = 0
    cores = []
    for (percent, color) in colors:
        percentual = float("{:0.2f}".format(percent * 100))
        #print(color, "{:0.2f}%".format(percent * 100))
        cores.append(percentual)
        end = start + (percent * 300)
        cv.rectangle(rect, (int(start), 0), (int(end), 50), \
                      color.astype("uint8").tolist(), -1)
        start = end
    #print(cores)
    return rect

def fc_perda_branca_nc(img):
    #filename = input('File name: ')
    #url = r'C:\\Users\\TAGNA\\Desktop\\Bayer\\sprint 2\\mascaras separacao de cores\\originais e mascaras\\Finais\\'  
    #url = r'C:\\Users\\TAGNA\\Desktop\\Camera Bayer\\Codigos_modelo\\'
    #url = url + str(filename)
    #url = url + '.jpg'
    #img = cv.imread(str(url))
    img2 = img[341:1349, 628:1462]

    full = milho(img2,(0, 0, 180), (255, 255, 255))
    #amarelo = milho(img,(0, 118, 190), (33, 255,255))
    cv.imwrite(r'maskFULL.jpg', full)
    image = cv.cvtColor(full, cv.COLOR_BGR2RGB)
    reshape = image.reshape((image.shape[0] * image.shape[1], 3))
    start_time = datetime.now()
    centroid_start = np.array([[0,0,0], #PRETO
                               [248,167,48], #BEGE
                               [160, 62, 0], #BEGE2
                               [153, 82, 33], #iNTERMEDIARIO DO MEIO
                               [198, 130, 109], #VERMELHO AMARRONZADO
                               [188, 126, 119], #VERMELHO PERDA
                               [220,138, 22], #AMARELO
                               [238,218,174]], np.float64) #BRANCO
    cluster = KMeans(n_clusters = 8, init = centroid_start).fit(reshape)
    #
    #visualize = visualize_colors(cluster, cluster.cluster_centers_)
    #visualize = cv.cvtColor(visualize, cv.COLOR_RGB2BGR)
    #cv.imshow("teste", visualize)
    #
    end_time = datetime.now()

    
    #print('Duration: {}'.format(end_time - start_time))
    pixels = Counter(cluster.labels_)
    prop = pixels[0]/(sum(pixels.values()))
    fillment =  (sum(pixels.values())-pixels[0])/(sum(pixels.values())) #para calculo da vazao
        
    if (prop >= 0.99)or(prop<=0):
      #print("Esteira vazia")
      return [0,0]
    else:
      pc_perda = (pixels[5]+pixels[7])/(sum(pixels.values())-pixels[0])
      #print('% de perda branca:' + str(round(pc_branco * 100, 2)) + '%')
      pc_perda = pc_perda*100 #value in percentage
      output = [pc_perda,fillment]
      #return correction_factor(pc_perda)
      return(output)

def url_to_image(url):
    image_flag = 0
    while(image_flag==0):
        try:
            resp = urllib.request.urlopen(url)
            image = np.asarray(bytearray(resp.read()), dtype="uint8")
            image = cv.imdecode(image, cv.IMREAD_COLOR)
            cv.imwrite('temp.jpg' ,image)
            image_flag = 1
        except:
            print('Error on getting image from camera')
            time.sleep(3)
    return(image)

def save_opc(loss,median,flow,fill,counter,OPC_type):
    if(OPC_type==0):
        try:
            Loss = client.get_node("ns=2;i=2")
            Median = client.get_node("ns=2;i=3")
            Flow = client.get_node("ns=2;i=4")
            Fill = client.get_node("ns=2;i=5")
            Counter = client.get_node("ns=2;i=6")
            
            Loss.set_value(loss)
            Median.set_value(median)
            Flow.set_value(flow)
            Fill.set_value(fill)
            Counter.set_value(counter)
            print('Values saved on OPC Server - UA')
        except:
            print('Error on saving on OPC Server - UA')
    else:
        try:
            opc.write(('Despalha.Loss',loss))
            opc.write(('Despalha.Median',median))
            opc.write(('Despalha.Flow',flow))
            opc.write(('Despalha.Fill',fill))
            opc.write(('Despalha.Counter',counter))
            print('Values saved on OPC Server - DA')
        except:
            print('Error on saving on OPC Server - DA')

def correction_factor(loss_value):
    try:
        reg_params = np.load('reg_params.npy')
        return(reg_params[0]+loss_value*reg_params[1])
    except:
        try:
            time.sleep(0.5)
            reg_params = np.load('reg_params.npy')
            return(reg_params[0]+loss_value*reg_params[1])
        except:
            print('Error on loading correction factor file')
            print('No correction factor applied')
            return(loss_value)

def standarized_flow(url):
    picture = cv.imread(url)
    loss,fillment = fc_perda_branca_nc(picture)
    return(fillment)
